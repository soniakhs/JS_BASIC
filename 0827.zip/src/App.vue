<template>
  <div>
    <table-component :table-data="tableData"></table-component>
  </div>
</template>

<script>
import TableComponentVue from './components/TableComponent'

export default {
  components:{
    TableComponentVue
  },
  data(){
    return{
      tableData:[
        ['','',''],
        ['','',''],
        ['','','']
      ]
    }
  },
  methods:{

  }
}

</script>

<style>
  table{
        border-collapse: collapse;   
    }
    td{
        border: 1px solid #000;
        width: 40px;
        height: 40px;
        text-align: center;
    }
</style>
