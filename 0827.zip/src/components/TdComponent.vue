<template>
  <td>
      {{cellData}}
  </td>
</template>

<script>
export default {
    props:{
        cellData:String,
        index:Number,
        rowIndex:Number
    },
    data(){
        return{

        }
    }
}
</script>

<style>

</style>