<template>
  <table>
      <tr-component v-for="(rowData,index) in tableData" :key="index" :row-data="rowData" :row-index="rowIndex">
          
      </tr-component>
  </table>
</template>

<script>
import TrComponent from './TrComponent'

export default {
    components:{
        TrComponent,
    },
    props:{
        tableData : Array
    },
    data(){
        return{

        }
    },
    methods:{

    }
};
</script>

<style>
    
</style>